# socket-code-using-python
Socket code in python language.
